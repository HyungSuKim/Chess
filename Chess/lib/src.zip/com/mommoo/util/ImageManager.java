package com.mommoo.util;

import java.awt.*;

/**
 * Created by mommoo on 2017-07-14.
 */
public class ImageManager {
    public static final Image TEST = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/test.png"));
    public static final Image WRITE = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/write.png"));
    public static final Image CHECK = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/check.png"));
    public static final Image PANDA = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/panda.png"));
    public static final Image GIRIN = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/girin.png"));
    public static final Image LION = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/lion.png"));
    public static final Image TIGER = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/tiger.png"));
    public static final Image DOG = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/dog.png"));
    public static final Image FROG = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/frog.png"));
    public static final Image SHEEP = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/sheep.png"));
    public static final Image CAT = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/cat.png"));
    public static final Image PIG = Toolkit.getDefaultToolkit().getImage(ImageManager.class.getResource("/com/mommoo/resource/img/pig.png"));

}
