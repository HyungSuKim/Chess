package com.mommoo.flat.text.textarea;

import java.awt.*;

public interface AutoResizeModel {
    public String getText();
    public FontMetrics getFontMetrics();
    public float getLineSpacing();
}
