package com.mommoo.flat.text.textarea.alignment;

public enum FlatVerticalAlignment {
    TOP,
    CENTER,
    BOTTOM
}
