package com.mommoo.flat.text.textfield.format;

public enum FlatTextFormat {
    NUMBER_DECIMAL,
    TEXT,
    HEX_COLOR,
    SPECIAL_CHARACTER;
}
