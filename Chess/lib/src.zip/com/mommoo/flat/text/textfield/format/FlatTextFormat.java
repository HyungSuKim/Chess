package com.mommoo.flat.text.textfield.format;

public enum FlatTextFormat {
    NUMBER_DECIMAL,
    TEXT,
    SPECIAL_CHARACTER;
}
