package com.mommoo.flat.list.model;

public interface onComputeScroll {
    public void onScrollWhenPainting();
}
