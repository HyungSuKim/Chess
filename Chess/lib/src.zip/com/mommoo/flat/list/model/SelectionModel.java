package com.mommoo.flat.list.model;

public interface SelectionModel {
    public int getItemSize();
    public boolean isSingleSelectionMode();
}
