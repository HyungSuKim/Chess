package com.mommoo.flat.component;

import java.awt.*;

public interface OnPositionClickListener {
	public void onClick(int position, Component target);
}
