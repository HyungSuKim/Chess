package com.mommoo.flat.component.pager;

@FunctionalInterface
public interface OnPageSelectedListener {
    public void onPageSelected(int index);
}
