package com.mommoo.flat.component.pager;

public enum FlatTabAlignment {
    START,
    CENTER,
    END;
}
