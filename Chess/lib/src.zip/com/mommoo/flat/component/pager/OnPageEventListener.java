package com.mommoo.flat.component.pager;

public interface OnPageEventListener {
    public void onSelected();
}
