package com.mommoo.flat.component;

public interface OnLayoutListener {
    public void onLayout(int availableWidth, int availableHeight);
}
