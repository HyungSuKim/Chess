package com.mommoo.flat.component;

import java.awt.*;

public interface OnClickListener {
	public void onClick(Component component);
}
