package com.mommoo.flat.frame.popup;

public interface OnItemClickListener {
    public void onItemClick(int position, String message);
}
