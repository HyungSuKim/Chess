package com.mommoo.flat.frame;

public enum FrameLocation{
    NONE,
    CENTER_AT_SCREEN,
    CENTER_AT_COMPONENT,
    RELATIVE_AT_COMPONENT;
}
