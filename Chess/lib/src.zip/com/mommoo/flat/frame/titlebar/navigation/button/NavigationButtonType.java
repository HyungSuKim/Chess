package com.mommoo.flat.frame.titlebar.navigation.button;

/**
 * Created by mommoo on 2017-07-13.
 */
public enum NavigationButtonType {
    MINI,
    SIZE,
    EXIT;
}
