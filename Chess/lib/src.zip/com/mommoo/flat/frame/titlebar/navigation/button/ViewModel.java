package com.mommoo.flat.frame.titlebar.navigation.button;

public interface ViewModel {
    public int getWidth();
    public int getHeight();
}
