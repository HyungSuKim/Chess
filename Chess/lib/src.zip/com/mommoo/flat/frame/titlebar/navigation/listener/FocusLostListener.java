package com.mommoo.flat.frame.titlebar.navigation.listener;

public interface FocusLostListener {
    public void lost();
}
