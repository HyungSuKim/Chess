package com.mommoo.flat.frame.listener;

public interface OnMinimizeListener {
    public void onMinimize();
}
