package com.mommoo.flat.button;

public interface ButtonViewModel {
    public void repaint();
    public int getWidth();
    public int getHeight();
}
