package com.mommoo.flat.layout.linear.constraints;

public enum LinearSpace implements Cloneable{
    WRAP_CONTENT,
    WRAP_CENTER_CONTENT,
    MATCH_PARENT;
}
