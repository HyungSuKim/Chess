package com.mommoo.flat.layout.linear;

public enum Orientation {
    VERTICAL,
    HORIZONTAL;
}
