package com.mommoo.flat.layout.linear;

public enum Alignment {
    START,
    CENTER,
    END;
}
