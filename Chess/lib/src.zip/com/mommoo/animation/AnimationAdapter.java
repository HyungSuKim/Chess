package com.mommoo.animation;

import java.util.List;

public class AnimationAdapter implements AnimationListener{
    @Override
    public void onStart() {

    }

    @Override
    public void onAnimation(List<Double> resultList) {

    }

    @Override
    public void onStop() {

    }

    @Override
    public void onEnd() {

    }
}
