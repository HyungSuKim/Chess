package com.mommoo.flat.image;

public enum ImageOption{
    MATCH_PARENT,
    MATCH_WIDTH_KEEP_RATIO,
    MATCH_HEIGHT_KEEP_RATIO,
    BASIC_IMAGE_SIZE,
    BASIC_IMAGE_SIZE_CENTER;
}
