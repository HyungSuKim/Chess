package com.mommoo.flat.component;

import java.awt.*;

public interface OnPaintListener {
    public void onPaint(Graphics2D graphics2D);
}
