package com.mommoo.flat.frame.listener;

public interface OnExitListener {
    public void onExit();
}
