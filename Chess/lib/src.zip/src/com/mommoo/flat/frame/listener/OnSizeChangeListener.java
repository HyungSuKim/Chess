package com.mommoo.flat.frame.listener;

import java.awt.*;

public interface OnSizeChangeListener {
    public void onSizeChanged(Dimension size, Point location);
}
