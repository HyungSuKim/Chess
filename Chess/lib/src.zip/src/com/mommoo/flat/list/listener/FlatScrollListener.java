package com.mommoo.flat.list.listener;

public interface FlatScrollListener {
    public void onDrag(int scrollSensitivity);
}
